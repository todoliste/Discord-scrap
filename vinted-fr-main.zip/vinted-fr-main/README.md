# Vinted Bot Discord

Pour installer et lancer
```
npm i && node main.js
```

N'oubliez pas de configer votre token dans `config.json` et vos salons dans `channels.json`.
